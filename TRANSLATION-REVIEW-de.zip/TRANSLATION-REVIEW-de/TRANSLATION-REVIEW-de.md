# German Translation Review & Fixes — `translations/Diretta-de.md`

**What this is:** A corrected version of the German translation, produced by comparing
`translations/Diretta-de.md` line-by-line against the English source `Diretta.md`.
This note documents every change so you can review before merging. *(You do not need to
commit this note itself — it's just a cover letter / ready-made PR description.)*

**How to apply (pick one):**
- Replace `translations/Diretta-de.md` with the attached corrected file, **or**
- From the repo root: `git apply Diretta-de.patch`

---

## Guarantees

- **35 lines changed**, all in **prose, headings, and Markdown link targets only**.
- **No code blocks were touched.** Every fenced ```code``` block (1,770 lines incl. fences)
  is **byte-for-byte identical** to the current `translations/Diretta-de.md`, so copy-and-paste
  behaviour and build results are unchanged.
- **No lines added or removed** (file stays 2,958 lines), so line numbers below match both
  the old and new file.
- After the fixes: **0 broken internal anchors** (all 40), **0 untranslated English left in prose**
  (the loanword "Copy-and-Paste" is intentionally kept).

---

## 1. Untranslated content restored

These had been left in English (or half-translated) in the German file.

### 1a. Headings — Appendix 1 (Argon ONE) and Appendix 7

In the rest of the document, step headings are localized as **"Schritt N"**, but Appendix 1
still read **"Step N"**, and Appendix 7 mixed **"Part 1"** (English) with **"Teil 2"** (German).

| Line | Before | After |
|---:|---|---|
| 1088 | `### Step 1: Skip the argon1.sh script in the manual` | `### Schritt 1: Das argon1.sh-Skript aus der Anleitung überspringen` |
| 1091 | `### Step 2: Configure your system:` | `### Schritt 2: Ihr System konfigurieren:` |
| 1104 | `### Step 3: Configure udev permissions` | `### Schritt 3: udev-Berechtigungen konfigurieren` |
| 1111 | `### Step 4: Install the Argon One Package` | `### Schritt 4: Das Argon-One-Paket installieren` |
| 1136 | `### Step 5: Switch Argon ONE case ...` | `### Schritt 5: Argon-ONE-Gehäuse von Hardware- auf Softwaresteuerung umstellen` |
| 1155 | `### Step 6: Enable the Service` | `### Schritt 6: Den Dienst aktivieren` |
| 1164 | `### Step 7: Reboot` | `### Schritt 7: Neustart` |
| 1172 | `### Step 8: Verify the service` | `### Schritt 8: Den Dienst überprüfen` |
| 1178 | `### Step 9: Review Fan Mode and Settings:` | `### Schritt 9: Lüftermodus und Einstellungen überprüfen:` |
| 2480 | `### Part 1: Diretta Target USB Path Isolation` | `### Teil 1: USB-Pfad-Isolierung auf dem Diretta-Target` |

### 1b. Paragraphs / list items left in English

| Line | Note |
|---:|---|
| 1116 | "**Note:** If the above command fails with compiler errors…" → fully translated ("**Hinweis:** Falls der obige Befehl…"). |
| 1214 | "* **Part 1** covers the hardware-specific setup…" → translated ("* **Teil 1** behandelt…"). |
| 1215 | "* **Part 2** covers the software setup…" → translated ("* **Teil 2** behandelt…"). |
| 1217 | "**Note:** You will _only_ perform these steps on the Diretta Host." (first sentence was English) → translated. |
| 1287 | "Press each button you want to use and note its scancode…" → fully translated. |
| 2913 | List item 5 ("Re-apply the `motd` fix from Section 5.1 on the Host.") was English → translated. |
| 2916 | List item 8 ("Once back online, re-run the 'Configure Compatible Compiler Toolchain' script…") was English → translated, reusing the existing German term "Kompatible Compiler-Toolchain konfigurieren" from §8. |
| 364  | Half-translated sentence: "…klicken Sie [hier](…) **zu jump to the point-to-point network configuration steps for the Target.**" → tail fully translated. |

---

## 2. Broken internal anchor links fixed

Several in-page links still pointed at the **English** auto-generated anchors, so they did not
resolve inside the German document. Targets corrected to the German headings' anchors.

| Line | Old target (broken) | New target |
|---:|---|---|
| 1247 | `#part-2-control-script-software-setup` | `#teil-2-software-einrichtung-des-steuerungsskripts` |
| 2912 | `#44-run-system-and-menu-updates` | `#44-system--und-menü-updates-ausführen` |
| 2913 | `#51-pre-configure-the-diretta-host` | `#51-den-diretta-host-vorkonfigurieren` |
| 2914 | `#72-correct-sudoers-rule-precedence` | `#72-die-priorität-der-sudoers-regeln-korrigieren` |
| 2917 | `#81-on-the-diretta-target` | `#81-auf-dem-diretta-target` |
| 2918 | `#82-on-the-diretta-host` | `#82-auf-dem-diretta-host` |
| 364  | absolute URL `…/Diretta.md#52-pre-configure-the-diretta-target` (jumps to the **English** doc) | relative `#52-das-diretta-target-vorkonfigurieren` (stays in the German doc) |

*(The remaining 33 internal links were already correct.)*

---

## 3. Spelling, grammar, and stray English words

| Line | Before | After | Reason |
|---:|---|---|---|
| 211 | „Die `machine-id` **is** eine…" | „…**ist** eine…" | English "is" instead of German "ist". |
| 576 | „…Latenz**aritfakten**…" | „…Latenz**artefakten**…" | Typo (transposed letters; EN "latency artifacts"). |
| 794 | „(`/etc/group` **and** `/etc/gshadow`)" | „(… **und** …)" | Stray English "and". |
| 2144 | „**Note:** OPTIONAL…" | „**Hinweis:** OPTIONAL…" | Untranslated label. |
| 2487 | „**Führen** den folgenden Befehl…aus:" | „Führen **Sie** den…aus:" | Missing polite imperative pronoun "Sie". |
| 2770 | „…und **fügen** den folgenden Block ein." | „…und fügen **Sie** den…ein." | Missing "Sie" (parallel line 2714 already had it). |
| 1197 | „**Restarten** Sie den Dienst **neu**…" | „**Starten** Sie den Dienst **neu**…" | Anglicism + redundancy ("restart … again"). |
| 2911 | trailing whitespace | — | Removed a stray trailing space. |

---

## 4. Consistency

| Line | Before | After | Reason |
|---:|---|---|---|
| 1287 | `Strg+C` | `Ctrl+C` | The doc already uses `Ctrl+C` everywhere else (lines 1343, 1540, 1583, 2232, 2272). |
| 776, 1234, 1452 | `etc.` | `usw.` | The doc otherwise uses German "usw." (e.g. line 22). |
| 2933 | „**System Health Check** QA-Skript" | „**System-Gesundheitscheck**-QA-Skript" | The same term is rendered "System-Gesundheitscheck" in the 7 other checkpoint callouts. |

---

## 5. Optional follow-ups — NOT changed (inside code blocks)

The following are **inside fenced code blocks** and were therefore **left untouched**.
They are only **suggestions**; none are required for the guide to work. Listed here for completeness.

### 5a. Safe to localize (display-only text)

`echo` messages and systemd `Description=` fields. Purely cosmetic — translating them changes no
behaviour, and other `echo` strings in the doc are already in German (e.g. lines 1201, 1743, 2952).

| Line | Current (English) | Suggested (German) |
|---:|---|---|
| 867  | `Description=Check and repair /boot filesystem before other services` | `Description=/boot-Dateisystem vor anderen Diensten prüfen und reparieren` |
| 1099 | `echo "Enabling I2C parameter..."` | `echo "I2C-Parameter wird aktiviert..."` |
| 1551 | `Description=Roon IR Remote Service` | `Description=Roon-IR-Fernbedienungsdienst` *(or keep as a proper name)* |
| 1640 | `✅ Purist Mode is ACTIVE.\e[0m System optimized for the highest sound quality.` | `✅ Purist-Modus ist AKTIV.\e[0m System für höchste Klangqualität optimiert.` |
| 1642 | `⚠️ CAUTION: Purist Mode is DISABLED.\e[0m Background activity may impact sound quality.` | `⚠️ ACHTUNG: Purist-Modus ist DEAKTIVIERT.\e[0m Hintergrundaktivität kann die Klangqualität beeinträchtigen.` |
| 1681 | `Description=Revert Purist Mode on Boot to Ensure Standard Operation` | `Description=Purist-Modus beim Booten zurücksetzen, um Standardbetrieb sicherzustellen` |
| 1698 | `Description=Activate Purist Mode 60 seconds after boot` | `Description=Purist-Modus 60 Sekunden nach dem Booten aktivieren` |
| 2239 | `Description=Purist Mode Web UI` | `Description=Purist-Modus Web-UI` |
| 2579 | `Description=Disable EEE on end0 for Link Stability` | `Description=EEE auf end0 für Verbindungsstabilität deaktivieren` |
| 2655 | `Description=Set end0 link speed for Audio Purity` | `Description=end0-Verbindungsgeschwindigkeit für Audio-Reinheit festlegen` |

### 5b. Do NOT translate in isolation

The `text` example-output block around **lines 1654–1661** reproduces the **actual on-screen output
of the `purist-mode` program** (fetched via `curl` from `scripts/purist-mode`), which prints English.
Translating it here would make the guide disagree with what the user actually sees. Localize only if
the `purist-mode` script itself is localized in the repo (program **and** example output together).

### 5c. Must stay verbatim (not display text)

| Line | Content | Why |
|---:|---|---|
| 2174 | `echo "Flask" > …/requirements.txt` | `Flask` is the Python package name written into `requirements.txt`. |
| 2950 | `echo "usb_max_current_enable=1" \| sudo tee -a /boot/config.txt` | Literal boot-config directive. |

---

*Reviewed against `Diretta.md` (English source) on the date of this note. Happy to adjust any
wording choices to match your house style.*
